package kr.ac.sunmoon.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

import kr.ac.sunmoon.shared.Customer;

@RemoteServiceRelativePath("customerservice")
public interface CustomerService extends RemoteService
{
	public Customer[] findCustomers(String keyword, int option);
	public void registerCustomer(Customer customer);
}
