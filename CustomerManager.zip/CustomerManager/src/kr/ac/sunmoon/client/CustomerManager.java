package kr.ac.sunmoon.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyUpEvent;
import com.google.gwt.event.dom.client.KeyUpHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DecoratorPanel;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment.HorizontalAlignmentConstant;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Tree;
import com.google.gwt.user.client.ui.TreeItem;
import com.google.gwt.user.client.ui.VerticalPanel;

import kr.ac.sunmoon.shared.Customer;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class CustomerManager implements EntryPoint 
{
	public void onModuleLoad() 
	{
		// main panel
		final VerticalPanel vpMain = new VerticalPanel();
		vpMain.getElement().getStyle().setWidth(1024, Unit.PX);
		RootPanel.get("main").add(vpMain);
		
		// search panel
		HorizontalPanel hpSearch = new HorizontalPanel();
		vpMain.add(hpSearch);
		
		final ListBox lboxOption = new ListBox();
		lboxOption.getElement().getStyle().setMarginRight(5, Unit.PX);
		hpSearch.add(lboxOption);
		lboxOption.addItem("Brand name");
		lboxOption.addItem("Product name");
		lboxOption.addItem("Company name");
		lboxOption.addItem("Address");
		lboxOption.addItem("Phone");
		lboxOption.addItem("Price");
		lboxOption.addItem("Stock");
		
		final TextBox txtKeyword = new TextBox();
		hpSearch.add(txtKeyword);
		int mainWidth = vpMain.getOffsetWidth();
		int optionWidth = lboxOption.getOffsetWidth();
		txtKeyword.setWidth((mainWidth - optionWidth) + "px");
		lboxOption.setHeight(txtKeyword.getOffsetHeight() + "px");
		
		HTML htmlLine = new HTML("<hr>");
		vpMain.add(htmlLine);
		
		// result panel
		DecoratorPanel dp = new DecoratorPanel();
		dp.getElement().getStyle().setMarginTop(5, Unit.PX);
		vpMain.add(dp);
		
		ScrollPanel spResult = new ScrollPanel();
		spResult.getElement().getStyle().setWidth(1024, Unit.PX);
		spResult.getElement().getStyle().setHeight(300, Unit.PX);
		dp.setWidget(spResult);
		
		final Tree treeResult = new Tree();
		spResult.setWidget(treeResult);
		
		txtKeyword.addKeyUpHandler(new KeyUpHandler() {
			
			@Override
			public void onKeyUp(KeyUpEvent event) {
				// TODO Auto-generated method stub
				int keyCode = event.getNativeKeyCode();
				if(keyCode == 13)
				{
					String keyword = txtKeyword.getText().trim();
					if(keyword.length() == 0)
						return;
					
					int option = lboxOption.getSelectedIndex();
					
					CustomerServiceAsync service = GWT.create(CustomerService.class);
					service.findCustomers(keyword, option, new AsyncCallback<Customer[]>() {
						
						@Override
						public void onSuccess(Customer[] result) {
							// TODO Auto-generated method stub
							treeResult.removeItems();
							for(int i=0; i<result.length; i++)
							{
								TreeItem item = new TreeItem();
								item.setText(result[i].getbrandName() + " " + result[i].getproductName());
								treeResult.addItem(item);
								
								addChild(item, "Company name: " + result[i].getCompanyName());
								addChild(item, "Address: " + result[i].getAddress());
								addChild(item, "Phone: " + result[i].getPhone());
								addChild(item, "Price: " + result[i].getPrice());
								addChild(item, "Stock: " + result[i].getStock());
							}
						}
						
						@Override
						public void onFailure(Throwable caught) {
							// TODO Auto-generated method stub
							Window.alert("Sorry, please try again after few minutes.");
						}
					});
				}
			}
		});
		
		Button btnRegi = new Button();
		btnRegi.setText("Register a new product");
		btnRegi.getElement().getStyle().setMarginTop(5, Unit.PX);
		btnRegi.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				// TODO Auto-generated method stub
				CustomerRegistrationDialog dialog = new CustomerRegistrationDialog();
				dialog.setPopupPosition(Window.getClientWidth()/2-150, txtKeyword.getAbsoluteTop());
				dialog.show();
			}
		});
		vpMain.add(btnRegi);
		vpMain.setCellHorizontalAlignment(btnRegi, HorizontalPanel.ALIGN_RIGHT);
	}
	
	private void addChild(TreeItem item, String text)
	{
		TreeItem childItem = new TreeItem();
		childItem.setText(text);
		item.addItem(childItem);
	}
}
