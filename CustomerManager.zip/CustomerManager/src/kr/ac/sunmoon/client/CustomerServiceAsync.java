package kr.ac.sunmoon.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

import kr.ac.sunmoon.shared.Customer;

public interface CustomerServiceAsync 
{
	void findCustomers(String keyword, int option, AsyncCallback<Customer[]> callback);

	void registerCustomer(Customer customer, AsyncCallback<Void> callback);
}
