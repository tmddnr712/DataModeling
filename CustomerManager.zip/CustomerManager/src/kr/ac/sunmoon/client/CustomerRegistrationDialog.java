package kr.ac.sunmoon.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;

import kr.ac.sunmoon.shared.Customer;

public class CustomerRegistrationDialog extends DialogBox
{
	private TextBox[] txtInputs;
	
	public CustomerRegistrationDialog()
	{
		super(false, true);
		
		this.setText("Customer registration");
		
		Grid grid = new Grid(8, 2);
		this.setWidget(grid);
		
		addInputList(grid);
		addButtons(grid);
	}
	
	private void addButtons(Grid grid)
	{
		Grid btnGrid = new Grid(1, 2);
		grid.setWidget(7, 1, btnGrid);
		
		Button btnOk = new Button();
		btnOk.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				// TODO Auto-generated method stub
				String[] inputs = new String[7];
				for(int i=0; i<inputs.length; i++)
				{
					inputs[i] = txtInputs[i].getText().trim();
					if(inputs[i].equals(""))
					{
						Window.alert("All the entries are required");
						return;
					}
				}
				
				Customer customer = new Customer();
				customer.setbrandName(inputs[0]);
				customer.setproductName(inputs[1]);
				customer.setCompanyName(inputs[2]);
				customer.setAddress(inputs[3]);
				customer.setPhone(inputs[4]);
				customer.setPrice(inputs[5]);
				customer.setStock(inputs[6]);
				
				CustomerServiceAsync service = GWT.create(CustomerService.class);
				service.registerCustomer(customer, new AsyncCallback<Void>() {
					
					@Override
					public void onSuccess(Void result) {
						// TODO Auto-generated method stub
						Window.alert("Success!");
						CustomerRegistrationDialog.this.hide();
					}
					
					@Override
					public void onFailure(Throwable caught) {
						// TODO Auto-generated method stub
						Window.alert("Sorry, please try again after few minutes.");
						CustomerRegistrationDialog.this.hide();
					}
				});
			}
		});
		btnOk.setText("Ok");
		btnGrid.setWidget(0, 0, btnOk);
		
		Button btnCancel = new Button();
		btnCancel.setText("Cancel");
		btnCancel.addClickHandler(new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				// TODO Auto-generated method stub
				CustomerRegistrationDialog.this.hide();
			}
		});
		btnGrid.setWidget(0, 1, btnCancel);
	}
	
	private void addInputList(Grid grid)
	{
		txtInputs = new TextBox[7];
		
		Label lblbrandName = new Label("Brand name:");
		grid.setWidget(0, 0, lblbrandName);
		txtInputs[0] = new TextBox();
		grid.setWidget(0, 1, txtInputs[0]);
		
		Label lblproductName = new Label("Product name: ");
		grid.setWidget(1, 0, lblproductName);
		txtInputs[1] = new TextBox();
		grid.setWidget(1, 1, txtInputs[1]);
		
		Label lblCompany = new Label("Company :");
		grid.setWidget(2, 0, lblCompany);
		txtInputs[2] = new TextBox();
		grid.setWidget(2, 1, txtInputs[2]);
		
		Label lblAddress = new Label("Address :");
		grid.setWidget(3, 0, lblAddress);
		txtInputs[3] = new TextBox();
		grid.setWidget(3, 1, txtInputs[3]);
		
		Label lblPhone = new Label("Phone :");
		grid.setWidget(4, 0, lblPhone);
		txtInputs[4] = new TextBox();
		grid.setWidget(4, 1, txtInputs[4]);
		
		Label lblprice = new Label("Price :");
		grid.setWidget(5, 0, lblprice);
		txtInputs[5] = new TextBox();
		grid.setWidget(5, 1, txtInputs[5]);
		
		Label lblStock = new Label("Stock :");
		grid.setWidget(6, 0, lblStock);
		txtInputs[6] = new TextBox();
		grid.setWidget(6, 1, txtInputs[6]);
	}
}
