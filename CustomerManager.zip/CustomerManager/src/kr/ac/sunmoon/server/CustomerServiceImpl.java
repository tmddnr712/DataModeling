package kr.ac.sunmoon.server;

import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

import com.google.gwt.user.server.rpc.RemoteServiceServlet;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import kr.ac.sunmoon.client.CustomerService;
import kr.ac.sunmoon.shared.Customer;

public class CustomerServiceImpl extends RemoteServiceServlet implements CustomerService
{
	@Override
	public Customer[] findCustomers(String keyword, int option) 
	{
		String filePath = this.getServletContext().getRealPath("/") + "\\customer_data.csv";
		ArrayList<Customer> vecCustomer = new ArrayList<Customer>();
		try 
		{ 
	        FileReader filereader = new FileReader(filePath); 
	        CSVReader csvReader = new CSVReader(filereader); 
	        String[] record; 
	        boolean isFirst = true;
	        while((record = csvReader.readNext()) != null) 
	        { 
	        	if(isFirst)
	        		isFirst = false;
	        	else
	        	{
	        		if(record[option].indexOf(keyword)>=0)
	        		{
	        			Customer customer = new Customer();
	        			customer.setbrandName(record[0]);
	        			customer.setproductName(record[1]);
	        			customer.setCompanyName(record[2]);
	        			customer.setAddress(record[3]);
	        			customer.setPhone(record[4]);
	        			customer.setPrice(record[5]);
	        			customer.setStock(record[6]);
	        			vecCustomer.add(customer);
	        		}
	        	}
	        } 
	        csvReader.close();
	    } 
	    catch (Exception e) { 
	        e.printStackTrace();
	        
	        System.out.println(this.getServletContext().getRealPath("/"));
	    } 
			
		Customer[] customers = new Customer[vecCustomer.size()];
		for(int i=0; i<customers.length; i++)
			customers[i] = vecCustomer.get(i);
		
		return customers;
	}

	@Override
	public void registerCustomer(Customer customer) 
	{
		String filePath = this.getServletContext().getRealPath("/") + "\\customer_data.csv";
		try 
		{ 
	        FileWriter fileWriter = new FileWriter(filePath, true); 
	        CSVWriter csvWriter = new CSVWriter(fileWriter); 
	        
	        csvWriter.close();
	        fileWriter.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
